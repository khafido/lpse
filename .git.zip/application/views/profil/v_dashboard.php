<div class="panel panel-primary form-search">
  <!-- <div class="panel-body"> -->
<div class="row" style="padding-top:50px; padding-bottom:50px;">
  <div class="col-sm-4">
    <div class="text-center">
      <div><i class="fas fa-gavel" style="font-size:70px; color:#20BE9D;"></i></div>
      <!--<img style="height : 60px; width : 60px;" src="<?=base_url()?>/assets/web/img/home/news.png" alt="">-->
      <div style="font-size: 20;">Pemilihan Mitra</div>
      <div style="font-size: 20;"><?= $pemilihan ?></div><br><br>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="text-center">
      <div><i class="far fa-handshake" style="font-size:70px; color:#20BE9D;"></i></div>
      <div style="font-size: 20;">Pengerjaan</div>
      <div style="font-size: 20;"><?= $pengerjaan ?></div><br><br>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="text-center">
    <div><i class="far fa-clock" style="font-size:70px; color:#20BE9D;"></i></div>
      <!--<img style="height : 60px; width : 60px;" src="<?=base_url()?>assets/images/register.png" alt="">-->
      <div style="font-size: 20;">Selesai</div>
      <div style="font-size: 20;"><?= $selesai ?></div><br><br>
    </div>
  </div>
</div>
  <!-- </div> -->
</div>
